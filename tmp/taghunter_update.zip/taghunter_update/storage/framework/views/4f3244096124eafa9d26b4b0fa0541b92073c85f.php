<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Taghunter update</title>
        <link href="<?php echo e(asset('/includes/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(asset('/js/include/jquery-3.6.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/includes/jquery-ui-1.13.2.custom/jquery-ui.min.js')); ?>"></script>
    </head>
    <body class="antialiased">
        <h1>Taghunter update</h1>
    <?php echo $__env->make('vendor.laraupdater.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
 <script src="<?php echo e(asset('/includes/bootstrap/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/includes/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/includes/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
    
</html>
<?php /**PATH C:\xampp\htdocs\taghunter_update\resources\views/welcome.blade.php ENDPATH**/ ?>