
    
        <h1>Taghunter update v2</h1>
        <p>this is the new update</p>
    @include('vendor.laraupdater.notification')   
 <script src="{{ asset('/includes/bootstrap/js/popper.min.js') }}"></script>
  <script src="{{ asset('/includes/bootstrap/js/bootstrap.min.js') }}"></script>
  <script src="{{ asset('/includes/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

